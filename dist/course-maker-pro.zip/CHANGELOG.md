# Course Maker Pro Theme Changelog

## [2.0.2] - Initial release
The initial release of the Course Maker Pro theme.
