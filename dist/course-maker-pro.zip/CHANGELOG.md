# Course Maker Theme Changelog
## [2.0.0] - Initial release.
