# Course Maker Theme Changelog

## [2.0.1] - Initial release
The initial release of the Course Maker Pro theme.
