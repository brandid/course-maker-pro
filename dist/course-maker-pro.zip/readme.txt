Course Maker Pro
- A Course Authoring WordPress Theme from brandiD

DESCRIPTION
Lead your online class with style, organization and the most user-friendly course interface in the StudioPress / Genesis suite, which can be customized to reflect your style and sensibility.

The homepage layout will drive traffic to your site and engage users with your course materials while communicating that you're an authority in your space, without actually saying that — unless you want it to!

The Course Maker Pro theme, built exclusively for the Genesis framework, is packed full of features and functionality to help you market your new online course. We like it so much, we're using it for our own personal branding course!

PURCHASE THEME
To purchase the theme, please visit:
https://thebrandidthemes.com/product/course-maker-theme/

THEME DEMO
To see a demo of the theme in action, please visit:
https://demo.coursemakerpro.thebrandid.com/

DOCUMENTATION
For theme documentation, please visit:
https://thebrandidthemes.com/docs/course-maker-pro/

PRODUCT SUPPORT
For product support, please visit:
https://buildmybrandid.com/product-support/
