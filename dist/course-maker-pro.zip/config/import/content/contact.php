<?php
/**
 * Course Maker Pro - One-Click Demo Install - Contact page content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Course Maker Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph {"align":"center"} -->
<p style="text-align:center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed cursus ultricies tellus, id congue quam tristique ut. Nulla scelerisque molestie convallis.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p style="text-align:center">To display an Opt-in form, simply install your favorite Forms plugin. Then, replace this text with your Form Shortcode or Block.</p>
<!-- /wp:paragraph -->
CONTENT;
