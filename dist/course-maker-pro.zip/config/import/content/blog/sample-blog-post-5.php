<?php
/**
 * Course Maker Pro - One-Click Demo Install - Sample Blog post content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Course Maker Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc sodales at velit pulvinar dignissim. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum ac condimentum dolor. Maecenas eleifend dignissim dignissim. Maecenas vehicula, ipsum et fringilla volutpat, felis velit efficitur sem, a euismod leo felis vel arcu. Sed nec elementum metus. Praesent luctus nisi ac turpis pulvinar lobortis. Maecenas erat magna, laoreet eu porta at, commodo eu quam. Nulla lacinia arcu sed augue lacinia, non consequat leo hendrerit. Vivamus dictum porttitor enim, in blandit orci venenatis eget. Nulla at tellus egestas quam porta pretium. Aliquam a finibus est.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Suspendisse molestie commodo ante eu finibus. Duis eget gravida ex. Duis sit amet nulla odio. Aliquam tempor fermentum auctor. Phasellus vel quam varius, convallis ante id, dictum urna. Curabitur cursus est erat, eu placerat quam sagittis in. Duis pellentesque vitae mauris nec facilisis.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed imperdiet nulla et elit varius, et ultrices purus varius. Donec tincidunt in tortor ut venenatis. Quisque sed imperdiet velit, at fringilla leo. Sed in nulla eu felis facilisis lobortis vel a risus. Aliquam lobortis velit sed quam hendrerit, at scelerisque purus commodo. Sed accumsan porta nulla, eu rutrum urna mollis vitae. Aenean laoreet aliquam tristique. Aliquam in augue sit amet libero semper fringilla vitae vel tellus. Suspendisse vitae efficitur mi, sed pharetra dui. Donec eu dapibus nulla.</p>
<!-- /wp:paragraph -->
CONTENT;
