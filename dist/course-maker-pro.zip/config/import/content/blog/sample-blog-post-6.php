<?php
/**
 * Course Maker Pro - One-Click Demo Install - Sample Blog post content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Course Maker Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel nunc condimentum, malesuada nunc in, efficitur justo. Nam consequat est eu nisi condimentum consectetur. Curabitur consequat nulla ut nulla placerat condimentum. Suspendisse potenti. Mauris eu libero sollicitudin nibh pellentesque dapibus vel sed ligula. Quisque blandit sit amet est non placerat. Sed blandit nunc sapien, quis laoreet odio malesuada vitae. Nullam fringilla ac neque ut semper. Etiam in pretium nunc, eu fringilla ante. Etiam facilisis at lectus vitae dapibus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Pellentesque ac risus ligula.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Suspendisse ultrices purus in magna viverra, non accumsan dolor viverra. Aenean id velit ultricies diam vulputate pulvinar. Praesent elementum tempus ullamcorper. Maecenas non volutpat sem, quis rhoncus erat. Suspendisse potenti. Integer quis erat eget leo condimentum aliquam. Suspendisse eget placerat massa, sit amet ornare magna. Aliquam consectetur libero a nunc luctus, non scelerisque turpis tempor. Vestibulum facilisis eget felis eget scelerisque. Nunc malesuada mollis aliquet. Nulla a aliquet augue.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nulla sed imperdiet nibh. Pellentesque bibendum id metus tristique volutpat. Ut pellentesque ut ante vitae viverra. Nam ante elit, vehicula nec tellus sit amet, interdum blandit diam. Duis quis venenatis nisi. In hac habitasse platea dictumst. Mauris sit amet iaculis risus. Mauris sollicitudin metus sit amet libero tincidunt tincidunt. Sed at ullamcorper odio. Donec quis sapien sit amet arcu pharetra lacinia. Suspendisse ante tellus, convallis et lorem et, laoreet posuere elit. Proin suscipit enim id semper vestibulum. Maecenas ac quam dui.</p>
<!-- /wp:paragraph -->
CONTENT;
