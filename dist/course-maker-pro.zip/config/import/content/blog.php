<?php
/**
 * Course Maker Pro - One-Click Demo Install - Blog page content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Course Maker Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph {"align":"center"} -->
<p style="text-align:center">This is where the magic happens! Include a brief paragraph at the top of your blog so readers know what topics or themes they can expect to read about — and look forward to!</p>
<!-- /wp:paragraph -->
CONTENT;
